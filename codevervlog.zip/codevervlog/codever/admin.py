from django.contrib import admin
from .models import MyProfile, MyPost, MyCategory, Rating, Comment, MyMessage

class MyProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'dob','address','gender','phone','dp')

class MyPostAdmin(admin.ModelAdmin):
    list_display = ( 'postedby', 'title', 'content', 'category', 'timestamp')

class MyCategoryAdmin(admin.ModelAdmin):
    list_display = ('title',  'img', 'timestamp')
    
class RatingAdmin(admin.ModelAdmin):
    list_display = ('post', 'rating_value', 'rated_by' )

class CommentAdmin(admin.ModelAdmin):
    list_display = ('post', 'comment_text' , 'commented_by', 'parent' )
    
class MyMessageAdmin(admin.ModelAdmin):
    list_display = ('name','email','phone','msg')

admin.site.register(MyProfile,MyProfileAdmin)
admin.site.register(MyPost, MyPostAdmin)
admin.site.register(MyCategory, MyCategoryAdmin)
admin.site.register(MyMessage, MyMessageAdmin)
admin.site.register(Rating, RatingAdmin)
admin.site.register(Comment, CommentAdmin)