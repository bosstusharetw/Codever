from django.apps import AppConfig


class CodeverConfig(AppConfig):
    name = 'codever'
