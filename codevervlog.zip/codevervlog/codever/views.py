from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import MyProfile, MyPost, MyCategory, Rating, Comment, MyMessage
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
import random
import json
from django.core.mail import send_mail
from django.db.models import Q
otp=''
message=''

def logOut(request):
    logout(request)
    return redirect('/')

def index(request):
    category = MyCategory.objects.all().order_by('-timestamp')
    recent = MyPost.objects.all().order_by('-timestamp')[0:7]
    try:
        profile = MyProfile.objects.get(user=request.user)
        return render(request,'index.html',{'category': category, 'recent':recent, 'profile':profile })

    except:
        return render(request,'index.html',{'category': category, 'recent':recent})
        
def rating(request,id):
    post = MyPost.objects.get(id=id)
    rating=request.POST.get('rating')
    profile = MyProfile.objects.get(user=request.user)
    rating_instance = Rating.objects.filter(post=post, rated_by=profile)
    if len(rating_instance) == 0:
        r = Rating(
            post= post,
            rating_value = rating,
            rated_by = profile,
        )
        r.save()
    else:
        rating_instance =  Rating.objects.get(post=post, rated_by=profile)
        rating_instance.rating_value = rating
        rating_instance.save()
    return HttpResponse('success')
              
def deletecomment(request,id):
    print('hello')
    comment = Comment.objects.get(id=id)
    comment.delete()
    return HttpResponse('success')

def comment(request,id):
    profile = MyProfile.objects.get(user=request.user)
    post = MyPost.objects.get(id=id)
    comment=request.POST.get('comment')
    c = Comment(
        post= post,
        comment_text = comment,
        commented_by = profile,
    )
    c.save()
    return HttpResponse('success')

def post(request, pk):
    category = MyCategory.objects.all().order_by('-timestamp')
    post = MyPost.objects.get(slug=pk)
    rating = Rating.objects.filter(post=post)
    sum=0
    for r in rating:
        sum += r.rating_value
    postrating = round(float(sum/len(rating)), 1)
    try:
        profile = MyProfile.objects.get(user=request.user)
        profile = MyProfile.objects.get(user=request.user)
        rating = Rating.objects.filter(post=post, rated_by=profile)
        mycomments = Comment.objects.filter(post=post, commented_by=profile)
        othercomments = Comment.objects.filter(~Q(commented_by=profile),post = post)
        return render(request,'post.html',{'category': category, 'post': post, 'profile':profile, 'rating':rating, 'mycomments':mycomments, 'othercomments':othercomments, 'postrating': postrating  })
    except:
        othercomments = Comment.objects.filter(post = post)
        return render(request, 'post.html', {'category': category, 'post': post, 'othercomments':othercomments, 'postrating': postrating })

def addpost(request):
    category = MyCategory.objects.all().order_by('-timestamp')
    try:
        profile = MyProfile.objects.get(user=request.user)
        return render(request,'addpost.html',{'category': category, 'profile':profile })

    except:
        return render(request, 'addpost.html', {'category': category, })

def addcategory(request):
    category = MyCategory.objects.all().order_by('-timestamp')
    try:
        profile = MyProfile.objects.get(user=request.user)
        return render(request,'addcategory.html',{'category': category, 'profile':profile })

    except:
        return render(request, 'addcategory.html', {'category': category})
        
def submitcategory(request):
    category_name = request.POST['category']
    img = request.FILES['featurephoto']
    category = MyCategory(
        title = category_name,
        img = img,
    )
    category.save()
    slug = category.slug
    return redirect('/category/'+slug)

def signin(request):
    username = request.POST['username']
    password = request.POST['password']
    user = authenticate(request, username=username, password=password)
    if user is not None:
        login(request, user)
    return redirect('/')

def register(request):
    otp_entered=request.POST['otp']
    if otp_entered == otp:
        try:
            first=request.POST['first']
            last=request.POST['last']
            email=request.POST['email']
            phone=request.POST['phone']
            pwd=request.POST['pwd']
            user = User.objects.create_user(first_name=first, username=email, last_name=last, password=pwd,email=email)
            user.save()
            profile=MyProfile(user=user,phone=phone)
            profile.save()
            login(request, user)
            response={
                'status':True,
                'message':'Registration successful',
            }
        
        except:
            email=request.POST['email']
            pwd=request.POST['pwd']
            user=authenticate(request, username=email, password=pwd)
            login(request,user)
            response={
                'status':True,
                'message':'You are an existing user',
            }
        
    else:
        response={
            'status':False,
            'message':'OTP is invalid',
        }
    return HttpResponse(json.dumps(response),content_type='json/application')

def sendotp(request):
    email=request.GET['email']
    global otp
    otp=str(random.randint(100000,999999))
    print(otp)
    send_mail(
        'OTP',
        otp,
        '',
        [email],
        fail_silently=False,
    )
    return HttpResponse('success')
  
def resetpassword(request):
    email=request.GET['email']
    user=User.objects.get(email=email)
    new_pwd = str(random.randint(10000000,99999999))
    send_mail(
        'Your New Password',
        new_pwd,
        '',
        [email],
        fail_silently=False,
    )
    user.set_password(new_pwd)
    user.save()
    return HttpResponse('success')

def profile(request):
    category = MyCategory.objects.all().order_by('-timestamp')
    global message
    profile=MyProfile.objects.get(user=request.user)
    return render(request,"profile.html",{'category': category,'profile':profile, 'message':message})

def updateprofile(request):
    dp=request.FILES['dp']
    name=request.POST['name']
    first=''.join(name.split()[:-1])
    last=name.split()[-1]
    dob=request.POST['dob']
    gender=request.POST['gender']
    addr=request.POST['addr']
    profile=MyProfile.objects.get(user=request.user)
    user=User.objects.get(email=request.user)
    user.first_name=first
    user.last_name=last
    profile.dp=dp
    profile.dob=dob
    profile.address=addr
    profile.gender=gender
    user.save()
    profile.save()
    return redirect('/profile')

def changepassword(request):
    old_pwd=request.POST['old_pwd']
    new_pwd=request.POST['new_pwd']
    user=authenticate(request,username=request.user,password=old_pwd)
    if user is not None:
        user=User.objects.get(email=request.user)
        user.set_password(new_pwd)
        user.save()
        login(request, user)
        response={
            'status':True,
            'message':'Password Updated Successfully',
        }
    else:
        response={
            'status':False,
            'message':'Enter correct password',
        }
    return HttpResponse(json.dumps(response),content_type='json/application')

def search(request, q):
    category = MyCategory.objects.all().order_by('-timestamp')
    try:
        profile = MyProfile.objects.get(user = request.user)
    except:
        profile = ''
    postresult=MyPost.objects.filter(title__contains=q)
    categoryresult=MyCategory.objects.filter(title__contains=q)
    return render(request,'searchresult.html',{'profile':profile, 'category':category, 'categoryresult':categoryresult, 'postresult':postresult})

def submitpost(request):
    category = request.POST['category']
    img = request.FILES['featurephoto']
    title = request.POST['title']
    content = request.POST['content'] 
    category = MyCategory.objects.get(title = category)
    post = MyPost(
        postedby = request.user,
        title = title,
        content = content,
        category = category,
        img = img
    )
    post.save()
    slug = post.slug
    return redirect('/post/'+slug)
    
def category(request,pk):
    category = MyCategory.objects.all().order_by('-timestamp')
    categoryname = MyCategory.objects.get(slug=pk)
    post = MyPost.objects.filter(category=categoryname).order_by('-timestamp')
    try:
        profile = MyProfile.objects.get(user=request.user)
        return render(request,'category.html',{'category': category, 'categoryname': categoryname,  'post':post, 'profile':profile })
    except:
        return render(request, 'category.html', {'categoryname': categoryname, 'category': category, 'post':post})
    
def contact(request):
    category = MyCategory.objects.all().order_by('-timestamp')
    try:
        profile = MyProfile.objects.get(user=request.user)
        return render(request, 'contact.html',{'profile':profile, 'category':category})
    except:
        return render(request, 'contact.html',{'category':category})
    
def about(request):
    return render(request, 'about.html')

def contactmessage(request):
    phone=request.POST['phone']
    name=request.POST['name']
    email=request.POST['email']
    msg=request.POST['msg']
    message = MyMessage(
        phone=phone,
        name=name,
        email=email,
        msg=msg,
    )
    message.save()
    response={
        'status':True,
        'message':'Your message has been sent successfully!',
        }
    return HttpResponse(json.dumps(response),content_type='json/application')

def community(request):
    category = MyCategory.objects.all().order_by('-timestamp')
    profile=MyProfile.objects.get(user=request.user)
    return render(request, 'community.html',{'category': category,'profile':profile})