from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
import itertools
from django.utils.text import slugify

class MyProfile(models.Model):
    slug = models.SlugField(unique=True)
    dob = models.DateField(default='2000-01-01')
    user = models.OneToOneField(to=User, on_delete=models.CASCADE)
    address = models.TextField(null=True, blank=True, default="")
    gender = models.CharField(max_length=20, null=True, choices=(("Male","Male"), ("Female","Female")))
    phone = models.CharField(unique=True, max_length=10, null=True, blank=True,)
    dp=models.ImageField(upload_to = "images\\%Y\\%m\\%d\\", default='images\\defaultdp.png')
    update_time = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return self.user.username
        
    def _generate_slug(self):
        value = self.user.first_name + " "+self.user.last_name
        slug_candidate = slug_original = slugify(value, allow_unicode=True)
        for i in itertools.count(1):
            if not MyProfile.objects.filter(slug=slug_candidate).exists():
                break
            slug_candidate = '{}-{}'.format(slug_original, i)

        self.slug = slug_candidate

    def save(self, *args, **kwargs):
        if not self.pk:
            self._generate_slug()

        super().save(*args, **kwargs)

class MyCategory(models.Model):
    slug = models.SlugField(editable=False)
    title = models.CharField(max_length= 1000)
    img = models.ImageField(null=True, blank=True, )
    timestamp = models.DateTimeField(default = datetime.now) 

    def __str__(self):
        return self.title
    
    def _generate_slug(self):
        value = self.title
        slug_candidate = slug_original = slugify(value, allow_unicode=True)
        for i in itertools.count(1):
            if not MyCategory.objects.filter(slug=slug_candidate).exists():
                break
            slug_candidate = '{}-{}'.format(slug_original, i)

        self.slug = slug_candidate

    def save(self, *args, **kwargs):
        if not self.pk:
            self._generate_slug()

        super().save(*args, **kwargs)

class MyPost(models.Model):
    slug = models.SlugField(editable=False)
    img = models.ImageField(null=True, blank=True, )
    postedby = models.ForeignKey(User, models.CASCADE)
    title = models.CharField(max_length= 1000)
    content = models.TextField()
    category = models.ForeignKey(MyCategory, models.CASCADE)
    timestamp = models.DateTimeField(default = datetime.now)

    def __str__(self):
        return self.title
    

    def _generate_slug(self):
        value = self.title
        slug_candidate = slug_original = slugify(value, allow_unicode=True)
        for i in itertools.count(1):
            if not MyPost.objects.filter(slug=slug_candidate).exists():
                break
            slug_candidate = '{}-{}'.format(slug_original, i)

        self.slug = slug_candidate

    def save(self, *args, **kwargs):
        if not self.pk:
            self._generate_slug()

        super().save(*args, **kwargs)

class Rating(models.Model):
    post = models.ForeignKey(to=MyPost , on_delete=models.CASCADE)
    rating_value = models.IntegerField( null=True, blank=True, choices=((1,1),(2,2),(3,3),(4,4),(5,5)))
    rated_by=models.ForeignKey(to=MyProfile, on_delete=models.CASCADE)
    timestamp=models.DateTimeField(default=datetime.now)
    def __str__(self):
        return "%s" % self.rating_value

class Comment(models.Model):
    post = models.ForeignKey(to=MyPost , on_delete=models.CASCADE)
    parent = models.ForeignKey( 'self', null=True,  blank=True, on_delete=models.CASCADE)
    comment_text = models.CharField(null=True, blank=True, max_length=1000)
    commented_by=models.ForeignKey(to=MyProfile, on_delete=models.CASCADE)
    timestamp=models.DateTimeField(default=datetime.now)
    def __str__(self):
        return "%s" % self.comment_text

class MyMessage(models.Model):
    name = models.CharField(max_length=50)
    phone = models.CharField(unique=True, max_length=10, null=True, blank=True,)
    email = models.EmailField(max_length=254)
    msg = models.TextField()
