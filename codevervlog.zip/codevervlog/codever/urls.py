from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('',views.index),
    path('signin',views.signin),
    path('profile',views.profile),
    path('updateprofile',views.updateprofile),
    path('sendotp',views.sendotp),
    path('changepassword',views.changepassword),
    path('resetpassword',views.resetpassword),
    path('register',views.register),
    path('post/<slug:pk>',views.post),
    path('addpost',views.addpost),
    path('logout',views.logOut),
    path('contact',views.contact),
    path('community',views.community),
    path('about',views.about),
    path('submit-post',views.submitpost),
    path('submit-category',views.submitcategory),
    path('category/<slug:pk>',views.category),
    path('addcategory',views.addcategory),
    path('profile',views.profile),
    path('rating/<int:id>',views.rating),
    path('comment/<int:id>',views.comment),
    path('contact/send',views.contactmessage),
    path('delete-comment/<int:id>',views.deletecomment),
    path('search/q=<str:q>',views.search),
]